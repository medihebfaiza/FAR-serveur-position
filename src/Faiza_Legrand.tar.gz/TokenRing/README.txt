Fonctionnalité : Token ring + passage du jeton

Le code fourni permet de créer le token ring entre les 6 processus qui sont créés.
Chaque processus crée une connexion avec un robot. Le premier processus crée le token,
et le fait passer au processus suivant au bout d'un temps arbitraire. La saisie des coordonnées
est possible mais la prise en compte de la saisie ne fonctionne pas encore.
